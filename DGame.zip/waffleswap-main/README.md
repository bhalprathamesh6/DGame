# DGame

## A Decentralized-Exchange on Ethereum

DGame is a DEX built on ethereum with a custom token called Waffle Coin. You can use this DApp to buy or sell Waffle Coin in exchange for Ethereum.

## Technologies Used

1. Nextjs and Tailwind CSS for the Frontend Application
2. Ganache Blockchain
3. Truffle and Web3.js for building and testing Smart Contracts
4. Solidity for defining the Smart Contracts backend

## How to run:
1. Clone the repo and install the required dependencies using "yarn -install"
2. Download [Ganache Suite](https://trufflesuite.com/ganache/index.html)
3. Install [Metamask](https://metamask.io/) for your browser
4. Create a custom RPC server in Metamask and copy the RPC URL from ganache. Chain ID is 1337. (For RPC: Either 7545 or 8545 should work). (Custom server should already exist on Metamask, delete that.)
5. Import test accounts from Ganache to Metamask by copying the account private keys from Ganache and import on Metamask via private key option.
6. With ganache running and metamask on stand-by, run cmd command "truffle migrate --reset" in the folder. This migrates all the contracts over to the blockchain. Then run command "truffle test". This command tests all the smart contracts to ensure their integrity.
7. After both the commands execute successfully, run command "yarn dev" to start the project.

